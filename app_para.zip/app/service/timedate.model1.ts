import { Time } from '@angular/common';

export class TimeDatewithDiff{
    constructor(public id:number, public s_date:Date, public s_time:Time, public e_date:Date, public e_time:Time, public diff:string){}
}