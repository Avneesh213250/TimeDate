import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';

import { Injectable } from '@angular/core';
import { TimeDate } from './timedate.model';
import { Time } from '@angular/common';
import { TimeDatewithDiff } from './timedate.model1';

@Injectable()
export class AppSrevice{

constructor(private http: HttpClient){}
editTime=new Subject<TimeDate>();

findById(id:number) : Observable<TimeDate>{
    return this.http.get<TimeDate>('http://localhost:8083/getTimeDateById/'+id);
}
updateTimeDate(id:number, data:TimeDate) : Observable<any>{
    return this.http.put<TimeDate>('http://localhost:8083/updateTimeDate/'+id, data);
}
save(timeDate:TimeDate) : Observable<TimeDate>{
    return this.http.post<TimeDate>('http://localhost:8083/saveTimeDate/',timeDate);
}
getAllTimeDate() : Observable<TimeDatewithDiff[]>{
    return this.http.get<TimeDatewithDiff[]>('http://localhost:8083/getAllTimeDate/');
}
deleteById(id:number) : Observable<any>{
    return this.http.delete<any>('http://localhost:8083/deleteTimeDate/'+id);
}
}