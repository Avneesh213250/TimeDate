import { Component, OnInit, ViewChild } from '@angular/core';
import { AppSrevice } from 'src/app/service/app.service';
import { TimeDate } from 'src/app/service/timedate.model';
import { FormGroup, FormControl, NgForm } from '@angular/forms';
import { Time } from '@angular/common';
import { element } from 'protractor';
import { MyService } from './myservise';
import { Router, ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-update-by-id',
  templateUrl: './update-by-id.component.html',
  styleUrls: ['./update-by-id.component.css']
})
export class UpdateByIdComponent implements OnInit {
 demoForm:FormGroup=new FormGroup({});
  constructor(private service:AppSrevice,
    private testservice:MyService,
    private router:Router,
    private route: ActivatedRoute) { }
  testData:TimeDate;
  flag=true;
testId:number;
  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      const id = +params['id'];
      this.testId=id;
      console.log(id);
      this.service.findById(id).subscribe(
        data=>{
          console.log(data.s_date);
          
          
          this.testData=data;
          console.log(this.testData);
           this.demoForm=new FormGroup({
       
     start:new FormGroup({
      s_date:new FormControl(this.fromJsonDate(this.testData.s_date)),
      s_time:new FormControl(this.testData.s_time)
     }),
    //  end:new FormGroup({
      e_date:new FormControl(this.fromJsonDate(this.testData.e_date)),
      e_time:new FormControl(this.testData.e_time)
    //  })
      
      
    });
        }
      );
    });

    }
    fromJsonDate(jDate): string {
      const bDate: Date = new Date(jDate);
      return bDate.toISOString().substring(0, 10);  //Ignore time
    }
    temp:any;
    onUpdate(){
  console.log(this.demoForm.value.start.s_date);
  
// this.temp.s_date=this.demoForm.value.start.s_date;
// this.temp.s_time=this.demoForm.value.start.s_time;
// this.temp.e_date=this.demoForm.value.e_date;
// this.temp.e_time=this.demoForm.value.e_time;
// console.log(this.temp);
this.service.updateTimeDate(this.testId, new TimeDate(null, this.demoForm.value.start.s_date, this.demoForm.value.start.s_time, this.demoForm.value.e_date, this.demoForm.value.e_time)).subscribe(
  element=>{
   console.log(element);
   this.router.navigate(['getAll']);
    
  }
);
    }
  
}
