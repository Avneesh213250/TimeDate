import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Time } from '@angular/common';
import { TimeDate } from 'src/app/service/timedate.model';

@Injectable()
export class MyService{
updateSubject= new Subject<TimeDate>();
}