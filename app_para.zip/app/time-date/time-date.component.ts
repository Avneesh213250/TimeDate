import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Time } from '@angular/common';
import { AppSrevice } from '../service/app.service';
import { TimeDate } from '../service/timedate.model';

@Component({
  selector: 'app-time-date',
  templateUrl: './time-date.component.html',
  styleUrls: ['./time-date.component.css']
})
export class TimeDateComponent implements OnInit {

  @ViewChild('demoForm') demoForm: NgForm;
  constructor(
    private router: Router,
    private route:ActivatedRoute,
    private service:AppSrevice){}

  s_date:Date;
  s_time:Time;
  e_date:Date;
  e_time:Time;
  ngOnInit(): void {

  }

onSubmit() { 
  this.s_date=this.demoForm.value.s_date;
  this.s_time=this.demoForm.value.s_time;
  this.e_date=this.demoForm.value.e_date;
  this.e_time=this.demoForm.value.e_time;
  console.log(this.demoForm.value);
  this.service.save(new TimeDate(null,this.s_date, this.s_time,this.e_date,this.e_time)).subscribe(
    data=>{
      console.log(data);
      
      this.router.navigate(['getAll']);
    }
    
  );
  }
}
