import { Component, OnInit } from '@angular/core';
import { TimeDate } from 'src/app/service/timedate.model';
import { AppSrevice } from 'src/app/service/app.service';
import { Router } from '@angular/router';
import { MyService } from '../update-by-id/myservise';
import { TimeDatewithDiff } from 'src/app/service/timedate.model1';

@Component({
  selector: 'app-get-all',
  templateUrl: './get-all.component.html',
  styleUrls: ['./get-all.component.css']
})
export class GetAllComponent implements OnInit {

  timeDateData:TimeDate;
  constructor(private service:AppSrevice,
    private router:Router,
    private testservice:MyService) { }
    diffInDays:TimeDatewithDiff[];
 timeDate:TimeDate[];
  ngOnInit(): void {
    localStorage.clear();
    this.service.getAllTimeDate().subscribe(

      (element:TimeDatewithDiff[])=>{
        this.diffInDays=element;
        
      }
    );
  }
  ondelete(index:number){
    let con=confirm('Are you sure?');
    if(con===true){
      this.timeDateData=this.diffInDays[index];
      console.log(this.timeDateData.id);
      this.service.deleteById(this.timeDateData.id).subscribe(
        data=>{
          alert("Successfully Deleted ");
          this.service.getAllTimeDate().subscribe(
            (element:TimeDatewithDiff[])=>{
              this.diffInDays=element;
            }
          );
        }
      );

    }
    
  }
  onEdit(index:number){
    this.timeDateData=this.diffInDays[index];
    console.log(this.timeDateData);

    this.service.editTime.next(this.timeDateData);
    this.testservice.updateSubject.next(this.timeDateData);
    this.router.navigate(['update',this.timeDateData.id]);
  }
}
