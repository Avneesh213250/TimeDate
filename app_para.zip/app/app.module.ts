import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component'; 
import { RouterModule, Routes} from '@angular/router';  

import { TimeDateComponent } from './time-date/time-date.component';
import { GetAllComponent } from './time-date/get-all/get-all.component';
import { UpdateByIdComponent } from './time-date/update-by-id/update-by-id.component';
import { AppSrevice } from './service/app.service';
import { HeaderComponent } from './header/header.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MyService } from './time-date/update-by-id/myservise';

const appRoute:Routes=[
  {path:'', redirectTo:'/create', pathMatch:'full'},
  {path:'create', component:TimeDateComponent},
  {path:'getAll', component:GetAllComponent},
  {path:'update/:id', component:UpdateByIdComponent}
];
@NgModule({
  declarations: [
    AppComponent,
    TimeDateComponent,
    GetAllComponent,
    HeaderComponent,
    UpdateByIdComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoute,{useHash:true})
  ],
  exports: [RouterModule],
  providers: [AppSrevice, MyService],
  bootstrap: [AppComponent]
})
export class AppModule { }
